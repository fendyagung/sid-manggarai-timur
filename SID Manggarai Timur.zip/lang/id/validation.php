<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Baris-baris Bahasa untuk Validasi
    |--------------------------------------------------------------------------
    |
    | Baris-baris bahasa berikut berisi pesan kesalahan standar yang digunakan oleh
    | kelas validator. Beberapa aturan memiliki beberapa versi seperti aturan size.
    | Silakan sesuaikan setiap pesan di sini.
    |
    */

    'accepted'        => ':attribute harus diterima.',
    'active_url'      => ':attribute bukan URL yang valid.',
    'after'           => ':attribute harus berisi tanggal setelah :date.',
    'after_or_equal'  => ':attribute harus berisi tanggal setelah atau sama dengan :date.',
    'alpha'           => ':attribute hanya boleh berisi huruf.',
    'alpha_dash'      => ':attribute hanya boleh berisi huruf, angka, strip, dan garis bawah.',
    'alpha_num'       => ':attribute hanya boleh berisi huruf dan angka.',
    'array'           => ':attribute harus berupa sebuah array.',
    'before'          => ':attribute harus berisi tanggal sebelum :date.',
    'before_or_equal' => ':attribute harus berisi tanggal sebelum atau sama dengan :date.',
    'between'         => [
        'numeric' => ':attribute harus bernilai antara :min sampai :max.',
        'file'    => ':attribute harus berukuran antara :min sampai :max kilobita.',
        'string'  => ':attribute harus berisi antara :min sampai :max karakter.',
        'array'   => ':attribute harus memiliki :min sampai :max item.',
    ],
    'boolean'         => ':attribute harus bernilai true atau false.',
    'confirmed'       => 'Konfirmasi :attribute tidak cocok.',
    'date'            => ':attribute bukan tanggal yang valid.',
    'date_equals'     => ':attribute harus berisi tanggal yang sama dengan :date.',
    'date_format'     => ':attribute tidak cocok dengan format :format.',
    'different'       => ':attribute dan :other harus berbeda.',
    'digits'          => ':attribute harus terdiri dari :digits angka.',
    'digits_between'  => ':attribute harus berukuran antara :min sampai :max angka.',
    'dimensions'      => ':attribute tidak memiliki dimensi gambar yang valid.',
    'distinct'        => ':attribute memiliki nilai yang duplikat.',
    'email'           => ':attribute harus berupa alamat email yang valid.',
    'ends_with'       => ':attribute harus diakhiri dengan salah satu dari: :values.',
    'exists'          => ':attribute yang dipilih tidak valid.',
    'file'            => ':attribute harus berupa sebuah berkas.',
    'filled'          => ':attribute harus memiliki nilai.',
    'gt'              => [
        'numeric' => ':attribute harus lebih besar dari :value.',
        'file'    => ':attribute harus lebih besar dari :value kilobita.',
        'string'  => ':attribute harus lebih panjang dari :value karakter.',
        'array'   => ':attribute harus memiliki lebih dari :value item.',
    ],
    'gte'             => [
        'numeric' => ':attribute harus lebih besar dari atau sama dengan :value.',
        'file'    => ':attribute harus lebih besar dari atau sama dengan :value kilobita.',
        'string'  => ':attribute harus lebih panjang dari atau sama dengan :value karakter.',
        'array'   => ':attribute harus memiliki :value item atau lebih.',
    ],
    'image'           => ':attribute harus berupa gambar.',
    'in'              => ':attribute yang dipilih tidak valid.',
    'in_array'        => ':attribute tidak ada di dalam :other.',
    'integer'         => ':attribute harus berupa bilangan bulat.',
    'ip'              => ':attribute harus berupa alamat IP yang valid.',
    'ipv4'            => ':attribute harus berupa alamat IPv4 yang valid.',
    'ipv6'            => ':attribute harus berupa alamat IPv6 yang valid.',
    'json'            => ':attribute harus berupa JSON string yang valid.',
    'lt'              => [
        'numeric' => ':attribute harus lebih kecil dari :value.',
        'file'    => ':attribute harus lebih kecil dari :value kilobita.',
        'string'  => ':attribute harus lebih pendek dari :value karakter.',
        'array'   => ':attribute harus memiliki kurang dari :value item.',
    ],
    'lte'             => [
        'numeric' => ':attribute harus lebih kecil dari atau sama dengan :value.',
        'file'    => ':attribute harus lebih kecil dari atau sama dengan :value kilobita.',
        'string'  => ':attribute harus lebih pendek dari atau sama dengan :value karakter.',
        'array'   => ':attribute harus memiliki tidak lebih dari :value item.',
    ],
    'max'             => [
        'numeric' => ':attribute tidak boleh lebih besar dari :max.',
        'file'    => ':attribute tidak boleh lebih besar dari :max kilobita.',
        'string'  => ':attribute tidak boleh lebih panjang dari :max karakter.',
        'array'   => ':attribute tidak boleh memiliki lebih dari :max item.',
    ],
    'mimes'           => ':attribute harus berupa berkas berjenis: :values.',
    'mimetypes'       => ':attribute harus berupa berkas berjenis: :values.',
    'min'             => [
        'numeric' => ':attribute harus minimal :min.',
        'file'    => ':attribute harus minimal :min kilobita.',
        'string'  => ':attribute harus minimal :min karakter.',
        'array'   => ':attribute harus memiliki minimal :min item.',
    ],
    'multiple_of'     => ':attribute harus merupakan kelipatan dari :value.',
    'not_in'          => ':attribute yang dipilih tidak valid.',
    'not_regex'       => 'Format :attribute tidak valid.',
    'numeric'         => ':attribute harus berupa angka.',
    'password'        => 'Kata sandi salah.',
    'present'         => ':attribute harus ada.',
    'regex'           => 'Format :attribute tidak valid.',
    'required'        => ':attribute wajib diisi.',
    'required_if'     => ':attribute wajib diisi bila :other adalah :value.',
    'required_unless' => ':attribute wajib diisi kecuali :other memiliki nilai :values.',
    'required_with'   => ':attribute wajib diisi bila terdapat :values.',
    'required_with_all' => ':attribute wajib diisi bila terdapat :values.',
    'required_without' => ':attribute wajib diisi bila tidak terdapat :values.',
    'required_without_all' => ':attribute wajib diisi bila sama sekali tidak terdapat :values.',
    'prohibited'      => ':attribute dilarang.',
    'prohibited_if'   => ':attribute dilarang bila :other adalah :value.',
    'prohibited_unless' => ':attribute dilarang kecuali :other ada di :values.',
    'same'            => ':attribute dan :other harus sama.',
    'size'            => [
        'numeric' => ':attribute harus berukuran :size.',
        'file'    => ':attribute harus berukuran :size kilobita.',
        'string'  => ':attribute harus berukuran :size karakter.',
        'array'   => ':attribute harus mengandung :size item.',
    ],
    'starts_with'     => ':attribute harus diawali salah satu dari: :values.',
    'string'          => ':attribute harus berupa string.',
    'timezone'        => ':attribute harus berisi zona waktu yang valid.',
    'unique'          => ':attribute sudah ada sebelumnya.',
    'uploaded'        => ':attribute gagal diunggah.',
    'url'             => 'Format :attribute tidak valid.',
    'uuid'            => ':attribute harus merupakan UUID yang valid.',

    /*
    |--------------------------------------------------------------------------
    | Baris-baris Bahasa untuk Validasi Kustom
    |--------------------------------------------------------------------------
    |
    | Di sini Anda dapat menentukan pesan validasi kustom untuk atribut dengan
    | menggunakan konvensi "attribute.rule" untuk menamai baris-baris tersebut.
    |
    */

    'custom' => [
        'attribute-name' => [
            'rule-name' => 'custom-message',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Atribut Validasi Kustom
    |--------------------------------------------------------------------------
    |
    | Baris-baris bahasa berikut digunakan untuk menukar place-holder atribut
    | kami dengan sesuatu yang lebih ramah pengguna seperti "Alamat Email"
    | daripada "email". Ini benar-benar membantu kami membuat pesan lebih bersih.
    |
    */

    'attributes' => [
        'email' => 'Alamat Email',
        'password' => 'Kata Sandi',
        'name' => 'Nama',
        'title' => 'Judul',
        'content' => 'Konten',
        'description' => 'Deskripsi',
        'phone' => 'Nomor Telepon',
        'address' => 'Alamat',
    ],

];
