<?php

use App\Models\DpmdProfile;
use App\Models\DpmdStaff;

require __DIR__ . '/../../vendor/autoload.php';

$app = require_once __DIR__ . '/../../bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

$profile = DpmdProfile::first();

if (!$profile) {
    echo "No DPMD Profile found.\n";
    exit;
}

$staffData = [
    ['nama' => $profile->nama_sekretaris, 'jabatan' => 'Sekretaris Dinas', 'urutan' => 1],
    ['nama' => $profile->nama_kabid_pemberdayaan, 'jabatan' => 'Bidang Pemberdayaan', 'urutan' => 2],
    ['nama' => $profile->nama_kabid_pemerintahan, 'jabatan' => 'Bidang Pemerintahan', 'urutan' => 3],
    ['nama' => $profile->nama_kabid_ekonomi, 'jabatan' => 'Bidang Ekonomi', 'urutan' => 4],
];

foreach ($staffData as $data) {
    if ($data['nama']) {
        DpmdStaff::updateOrCreate(
            ['nama' => $data['nama'], 'jabatan' => $data['jabatan']],
            [
                'dpmd_profile_id' => $profile->id,
                'urutan' => $data['urutan'],
                'is_active' => true
            ]
        );
        echo "Migrated: {$data['nama']} as {$data['jabatan']}\n";
    }
}

echo "Migration complete.\n";
