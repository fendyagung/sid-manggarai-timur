<?php
require 'vendor/autoload.php';
$app = require_once 'bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Desa;
use Illuminate\Support\Facades\DB;

$dupes = Desa::select('nama_desa', DB::raw('count(*) as total'))
    ->groupBy('nama_desa')
    ->having('total', '>', 1)
    ->get();

echo "Checking " . count($dupes) . " duplicates...\n";

foreach ($dupes as $d) {
    echo "\nName: [" . $d->nama_desa . "]\n";
    $items = Desa::where('nama_desa', $d->nama_desa)->get();
    foreach ($items as $i) {
        echo sprintf(
            "  - ID: %d | Kec: %s | UserID: %s | Created: %s\n",
            $i->id,
            $i->kecamatan,
            $i->user_id ?: '-',
            $i->created_at
        );
    }
}
