<?php
require 'vendor/autoload.php';
$app = require_once 'bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Desa;
use Illuminate\Support\Facades\DB;

$desas = Desa::all();
$grouped = [];
foreach ($desas as $d) {
    $name = trim($d->nama_desa);
    $grouped[$name][] = $d;
}

echo "Total distinct names: " . count($grouped) . "\n";

foreach ($grouped as $name => $list) {
    if (count($list) > 1) {
        echo "Duplicate found for: [$name]\n";
        // Keep the one with user_id or the one with the smallest ID
        $kept = null;
        foreach ($list as $item) {
            if ($item->user_id) {
                $kept = $item;
                break;
            }
        }
        if (!$kept) {
            usort($list, fn($a, $b) => $a->id <=> $b->id);
            $kept = $list[0];
        }

        foreach ($list as $item) {
            if ($item->id !== $kept->id) {
                echo "  Deleting ID: " . $item->id . " (Kecamatan: " . $item->kecamatan . ")\n";
                $item->delete();
            } else {
                echo "  Keeping ID: " . $item->id . " (Kecamatan: " . $item->kecamatan . ")\n";
            }
        }
    }
}

echo "Final count: " . Desa::count() . "\n";
