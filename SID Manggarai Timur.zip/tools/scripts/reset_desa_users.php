<?php

$desas = \App\Models\Desa::where('nama_desa', 'like', '%Balus Permai%')
    ->orWhere('nama_desa', 'like', '%Poco Rii%')
    ->get();

foreach($desas as $desa) {
    if ($desa->user_id) {
        \App\Models\User::where('id', $desa->user_id)->delete();
        $desa->update(['user_id' => null]);
        echo "Akun untuk Desa " . $desa->nama_desa . " berhasil dihapus dan dikosongkan.\n";
    } else {
        echo "Desa " . $desa->nama_desa . " memang sudah kosong (tidak ada admin).\n";
    }
}
