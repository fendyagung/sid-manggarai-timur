<?php
require 'vendor/autoload.php';
$app = require_once 'bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Desa;
$kecamatans = Desa::select('kecamatan')->distinct()->pluck('kecamatan')->toArray();
foreach ($kecamatans as $k) {
    echo "[$k]\n";
}
