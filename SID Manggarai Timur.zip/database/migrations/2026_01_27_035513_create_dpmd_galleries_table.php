<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('dpmd_galleries', function (Blueprint $table) {
            $table->id();
            $table->foreignId('dpmd_profile_id')->constrained('dpmd_profiles')->onDelete('cascade');
            $table->enum('type', ['foto', 'video']);
            $table->string('url_or_path');
            $table->string('caption')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('dpmd_galleries');
    }
};
